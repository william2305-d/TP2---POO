#include <iostream>
#include "Biblioteca.h"

 class Interface {
	public:
	static void PesquisarPublicacao(const Biblioteca &biblio);
	static void PesquisarLivro (const Biblioteca &biblio) ;	
	static void ListarPublicacao (Biblioteca &biblio) ;
 	static void ListarEmprestimos (const Biblioteca &biblio);
};
