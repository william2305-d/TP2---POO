#include <iostream>
#include <stdlib.h>
#include "Interface.h"
#include<vector>
#include <string>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {

try{
	Biblioteca b;
	Livro l("Alice",0,"tit","ed",2,2);
	Livro l2("Alic",0,"at","ed",2,2);
	Livro l3("Boca",0,"titulo","ed",2,2);
	Periodico p(3,"OLA",0,"tudo bom","ed", 3);
	b.novaPublicacao(&l);
	b.novaPublicacao(&l2);
	b.novaPublicacao(&l3);
	b.novaPublicacao(&p);
	Interface::PesquisarPublicacao(b);

}catch(Erro &e){
	e.out();
	
}

	return 0;
}
