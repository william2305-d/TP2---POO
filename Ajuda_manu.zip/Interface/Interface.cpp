#include <iostream>
#include <stdlib.h>
#include "Interface.h"
#include <string>
#include <vector>

void Interface::PesquisarPublicacao(const Biblioteca &biblio){
	string livro;
	cout << "Entre com o titulo da Publicacao que deseja pesquisar: ";
	cin >> livro;
	cout << endl;	
	vector <Publicacao*> livrosEncontrados;
	biblio.pesquisaPub(livro,livrosEncontrados);
	
	if( livrosEncontrados.size() == 0){
		throw Erro("Nao foi encontrada nenhuma publicacao");
	}
	
	for(int i =0 ; i < livrosEncontrados.size(); i ++){
		cout << i << " " << livrosEncontrados[i]->getTitulo() <<endl;
	}
	
}

void Interface::PesquisarLivro(const Biblioteca &biblio){ //N�o diferencia letra mauscula de minuscula
	string livro;
	cout << "Entre com o nome do autor do Livro que deseja pesquisar: ";
	cin >> livro;
	cout << endl;	
	vector <Livro*> livrosEncontrados;
	biblio.pesquisaAutores(livro,livrosEncontrados);
	
	if( livrosEncontrados.size() == 0){
		throw Erro("Nao foi encontrada nenhum livro");
	}
	
	for(int i =0 ; i < livrosEncontrados.size(); i ++){
		cout << i << " " << livrosEncontrados[i]->getAutores() <<endl;
	}	
}









