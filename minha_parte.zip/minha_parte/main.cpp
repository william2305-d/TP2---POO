#include <iostream>
#include "Biblioteca.h"
#include <vector>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
// Sobre como ser estatico
class tentativa{
	private: static int a;
	int b;
	public: 

	tentativa(){
		b=a;
		a++;
	};
	int get_a(){return a;
	};
	int get_b(){return b;
	};
	
	
};

int tentativa::a=0;

int main(int argc, char** argv) {
	tentativa c, b;
//	cout << c.get_b() << " " << b.get_b() << endl;
	
	vector <int> a;
	a.push_back(2);
	a.push_back(3);
	a.push_back(4);
	
//	a.erase(a.begin()+1);

	int i;
	for( i=0; i < a.size() ; i++){
		
			if(i == 2){
				break;
			}
			cout << i << endl;
				
	}
	
	cout << a.size() << " " << i;

	
	
	return 0;
}
